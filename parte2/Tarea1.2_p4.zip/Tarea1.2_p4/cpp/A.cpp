/*
 * A.cpp
 */


#include "../include/A.h"

void A::who() {
  std::cout << "A \n";
}
