/*
 * B.cpp
 */

#include "../include/B.h"

void B::who() {
  std::cout << "B \n";
}


