/*
 * C.cpp
 */

#include "../include/C.h"

void C::who() {
  std::cout << "C \n";
}
